import service.Interpreter;

/**
 * @author charlottexiao
 */
public class main {

    public static void main(String[] args) {
        new Interpreter().handleArgs(args);
    }

}
